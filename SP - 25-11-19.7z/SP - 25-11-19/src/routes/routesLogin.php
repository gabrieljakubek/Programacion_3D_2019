<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;
use App\Models\ORM\userControler;
use App\Models\ORM\logger;

include_once __DIR__ . '/../../src/app/modelORM/userControler.php';
include_once __DIR__ . '/../../src/app/modelORM/logger.php';

return function (App $app) {
    $container = $app->getContainer();

    $app->group('/login', function () {
        $this->post('/', userControler::class.':LogIn');
    })->add(logger::class . ":log");
};
