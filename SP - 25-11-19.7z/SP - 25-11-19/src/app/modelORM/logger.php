<?php

namespace App\Models\ORM;

use App\Models\ORM\log;
use App\Models\AutentificadorJWT;
use App\Models\IApiControler;

include_once __DIR__ . '/log.php';
class Logger
{
    public function log($request, $response, $next)
    {
        $token = "";
        $usuario = "No definido";
        $token = $request->getHeader('token');
        if (!empty($token)) {
            try {
                AutentificadorJWT::verificarToken($token[0]);
                $data = AutentificadorJWT::ObtenerData($token[0]);
                $data = "Email:".$data[0]->email . " - Legajo:" . $data[0]->legajo;
                $usuario = $data;
            } catch (\Exception $e) {
                $newResponse = $response->withJson("Token Invalido", 500);
            }
        }
        $ruta = $request->getRequestTarget();
        $metodo = $request->getMethod();
        $ip = $request->getServerParam('REMOTE_ADDR');
        $fecha = date('Y-m-d H:i:s', $request->getServerParam('REQUEST_TIME'));
        $log = new log;
        $log->ruta = $ruta;
        $log->metodo = $metodo;
        $log->usuario = $usuario;
        $log->ip = $ip;
        $log->fecha = $fecha;
        $log->save();
        $newResponse = $next($request, $response); // Se va a la funcion NEXT
        return $newResponse;
    }
}
