<?php

namespace App\Models\ORM;

use App\Models\AutentificadorJWT;
use App\Models\IApiControler;
use App\Models\ORM\user;
use App\Models\ORM\utils;
use App\Models\ORM\ficheo;

include_once __DIR__ . '/user.php';
include_once __DIR__ . '/ficheo.php';
include_once __DIR__ . '/utils.php';
include_once __DIR__ . '/userControler.php';
include_once __DIR__ . '../../modelAPI/IApiControler.php';
include_once __DIR__ . '../../modelAPI/AutentificadorJWT.php';

class userControler implements IApiControler
{
    const rutaImagenes = "../src/app/imagenes/users/";
    public function TraerTodos($request, $response, $args)
    {
        //return cd::all()->toJson();
        $usuarios = usuario::traerUsuarios();
        $newResponse = $response->withJson($usuarios, 200);
        return $newResponse;
    }

    public function TraerUno($request, $response, $args)
    {
        $usuario = usuario::traerUsuario($args['email']);
        if (count($usuario) == 0) {
            $newResponse = $response->withJson("No existe el usuario", 200);
        } else {
            $newResponse = $response->withJson($usuario, 200);
        }
        return $newResponse;
    }

    public function CargarUno($request, $response, $args)
    {
        $user = new user;
        $body = $request->getParsedBody();
        $files = $request->getUploadedFiles();
        if (isset($body["email"]) && isset($body["clave"]) && isset($body["legajo"]) && isset($files['foto1']) && isset($files['foto2'])) {
            $existe = user::traerUser($user["legajo"]);
            if (count($existe) == 0) {
                if ($body["legajo"] >= 1 && $body["legajo"] <= 1000) {
                    $user->email = $body["email"];
                    $user->clave = crypt($body["clave"], "st");
                    $user->legajo = $body["legajo"];
                    $existe = user::traerUser($user, 1);
                    if (count($existe) == 0) {
                        $uploadedFile = $files['foto1'];
                        utils::guardarArchivo($uploadedFile, userControler::rutaImagenes, $user['legajo'] . "_1");
                        $uploadedFile = $files['foto2'];
                        utils::guardarArchivo($uploadedFile, userControler::rutaImagenes, $user['legajo'] . "_2");
                        $user->save();
                        $respuesta = "Se guardo";
                    } else {
                        $respuesta = "Usuario ya existente";
                    }
                } else {
                    $respuesta = "El legajo debe estar entre 1 y 1000";
                }
            } else {
                $respuesta = "Legajo ya ingresado";
            }
        } else {
            $respuesta = "Faltan cargar datos";
        }
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
    }
    public function BorrarUno($request, $response, $args)
    {
        //complete el codigo
        $newResponse = $response->withJson("sin completar", 200);
        return $newResponse;
    }

    public function ModificarUno($request, $response, $args)
    {
        $contador = 0;
        $buscar = usuario::find($args["legajo"]);
        $token = $request->getHeader('token');
        $body = $request->getParsedBody();
        $data = AutentificadorJWT::ObtenerData($token[0]);
        $mensaje = "No se realizo ninguna modificacion";
        $uploadedFile = null;
        if (($buscar['id'] == $data[0]->id && $data[0]->tipo == 1) || ($data[0]->tipo == 3 && $buscar['tipo'] == 1)) {
            if (isset($body["email"]) && $body["email"] != $buscar["email"]) {
                $buscar['email'] = $body["email"];
                $buscar->save();
                $contador++;
            }
            $files = $request->getUploadedFiles();
            if (isset($files['foto'])) {
                $uploadedFile = $files['foto'];
                utils::guardarArchivo($uploadedFile, usuarioControler::rutaImagenes, $buscar['id']);
            }
            if ($uploadedFile != null) {
                $contador++;
            }
            if ($contador != 0) {
                $mensaje = " Se realizaron los cambios";
            }
        } else if (($buscar['id'] == $data[0]->id && $data[0]->tipo == 2) || ($data[0]->tipo == 3 && $buscar['tipo'] == 2)) {
            if (isset($body["email"]) && $body["email"] != $buscar["email"]) {
                $buscar['email'] = $body["email"];
                $buscar->save();
                $contador++;
            }
            if (isset($body["materias"])) {
                $materias = explode(",", $body["materias"]);
                $dando = materias_usuario::traerMaterias($buscar['id']);
                if ($dando == []) {
                    foreach ($materias as $m) {
                        $materia = new materias_usuario;
                        $materia->pk_materia = $m;
                        $materia->pk_usuario = $buscar['id'];
                        $materia->save();
                        $contador++;
                    }
                } else {
                    foreach ($materias as $m) {
                        $cargada = false;
                        foreach ($dando as $d) {
                            $int = intval($m);
                            if ($int == $d['pk_materia']) {
                                $cargada = true;
                            }
                        }
                        if ($cargada == false) {
                            $materia = new materias_usuario;
                            $materia->pk_materia = $m;
                            $materia->pk_usuario = $buscar['id'];
                            $materia->save();
                            $contador++;
                        }
                    }
                }
            }
            if ($contador != 0) {
                $mensaje = "Se realizaron los cambios";
            }
        } else {
            $mensaje = "No tiene la autorizacion para realizar la modificacion";
        }
        $newResponse = $response->withJson($mensaje, 200);
        return $newResponse;
    }

    public function LogIn($request, $response, $args)
    {
        $user = new user;
        $body = $request->getParsedBody();
        if (isset($body["email"]) && isset($body["clave"]) && isset($body["legajo"])) {
            $user->email = $body["email"];
            $user->clave = crypt($body["clave"], "st");
            $user->legajo = $body["legajo"];
            $validacion = user::traerUser($user, 1);
            if (count($validacion) != 0) {
                $token = AutentificadorJWT::CrearToken($validacion);
                $respuesta = array('estado' => "Acceso autorizado", 'token' => $token);
            } else {
                $respuesta = "Acceso no autorizado";
            }
        } else {
            $respuesta = "Ingrese email y clave";
        }
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
    }

    public function Ingreso($request, $response, $args)
    {
        $token = $request->getHeader('token');
        $data = AutentificadorJWT::ObtenerData($token[0]);
        $ingreso = ficheo::traerFicheo($data[0]->email);
      
        if (count($ingreso) == 0 || $ingreso[0]['estado'] == 0) {
            $ficheo = new ficheo;
            $ficheo->email= $data[0]->email;
            $ficheo->estado= 1;
            $ficheo->save();
            $respuesta = "Ingreso";
        } else {
            $respuesta = "Ya Ingreso";
        }
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;        
    }
    public function Egreso($request, $response, $args)
    {
        $token = $request->getHeader('token');
        $data = AutentificadorJWT::ObtenerData($token[0]);
        $ingreso = ficheo::traerFicheo($data[0]->email);
        $ficha = ficheo::find($ingreso[0]["id"]);
        if ($ingreso[0]['estado'] == 1) {
            $ficha->estado= 0;
            $ficha->save();
            $respuesta = "Egreso";
        } else {
            $respuesta = "Ya egreso";
        }
        $newResponse = $response->withJson($respuesta, 200);
        return $newResponse;
        
    }


}
