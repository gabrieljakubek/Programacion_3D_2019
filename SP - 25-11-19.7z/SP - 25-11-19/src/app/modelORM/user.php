<?php
namespace App\Models\ORM;

class user extends \Illuminate\Database\Eloquent\Model
{

    public static function traerUser($valor, $validacion = 2)
    {
        if ($validacion === 1) {
            $respuesta = self::select("id", "email", "legajo")
                ->where('email', $valor["email"])
                ->where('clave', $valor['clave'])
                ->where('legajo', $valor['legajo'])
                ->get();
        } else if ($validacion === 2) {
            $respuesta = self::select("id", "email", "legajo")
                ->where('legajo', $valor)
                ->get();
        } else if ($validacion === 3) {
            $respuesta = self::select("id", "email", "legajo")
                ->where('id', $valor)
                ->get();
        } else {
            $respuesta = "Opcion no valida";
        }
        return $respuesta;
    }
    public static function traerUsers()
    {
        $respuesta = self::select("id", "email", "tipo")->get();
        return $respuesta;
    }
}
