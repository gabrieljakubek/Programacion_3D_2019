<?php

namespace App\Models\ORM;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;


class ficheo extends \Illuminate\Database\Eloquent\Model
{
    public static function traerFicheo($valor)
    {
        $respuesta = self::select("id", "email", "estado","created_at","updated_at")
            ->where('email', $valor)
            ->get();
        return $respuesta;
    }
    // public static function traerFicheos()
    // {
    //     $respuesta = self::select("id", "email", "tipo")->get();
    //     return $respuesta;
    // }

}
