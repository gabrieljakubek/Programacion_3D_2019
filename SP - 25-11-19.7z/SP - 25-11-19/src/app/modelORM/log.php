<?php
namespace App\Models\ORM;

class log extends \Illuminate\Database\Eloquent\Model
{

}
