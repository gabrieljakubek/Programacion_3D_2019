-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-11-2019 a las 01:27:51
-- Versión del servidor: 10.1.38-MariaDB
-- Versión de PHP: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `segundoparcial`
--
CREATE DATABASE IF NOT EXISTS `segundoparcial` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
USE `segundoparcial`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ficheos`
--

CREATE TABLE `ficheos` (
  `id` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `estado` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `ficheos`
--

INSERT INTO `ficheos` (`id`, `email`, `estado`, `updated_at`, `created_at`) VALUES
(1, 'gabriel@gmail.com', 0, '2019-11-26 04:25:37', '2019-11-26 03:47:34'),
(5, 'gabriel@gmail.com', 1, '2019-11-26 04:26:02', '2019-11-26 04:26:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `ip` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `ruta` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `metodo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `usuario` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `logs`
--

INSERT INTO `logs` (`id`, `fecha`, `ip`, `ruta`, `metodo`, `usuario`, `created_at`, `updated_at`) VALUES
(14, '2019-11-26', '127.0.0.1', '/public/users/', 'POST', 'No definido', '2019-11-26 03:01:27', '2019-11-26 03:01:27'),
(15, '2019-11-26', '127.0.0.1', '/public/users/', 'POST', 'No definido', '2019-11-26 03:03:26', '2019-11-26 03:03:26'),
(16, '2019-11-26', '127.0.0.1', '/public/users/', 'POST', 'No definido', '2019-11-26 03:03:35', '2019-11-26 03:03:35'),
(17, '2019-11-26', '127.0.0.1', '/public/login/', 'POST', 'No definido', '2019-11-26 03:04:02', '2019-11-26 03:04:02'),
(18, '2019-11-26', '127.0.0.1', '/public/login/', 'POST', 'No definido', '2019-11-26 03:04:07', '2019-11-26 03:04:07'),
(19, '2019-11-26', '127.0.0.1', '/public/login/', 'POST', 'No definido', '2019-11-26 03:04:19', '2019-11-26 03:04:19'),
(20, '2019-11-26', '127.0.0.1', '/public/login/', 'POST', 'No definido', '2019-11-26 03:42:59', '2019-11-26 03:42:59'),
(21, '2019-11-26', '127.0.0.1', '/public/login/', 'POST', 'No definido', '2019-11-26 03:43:05', '2019-11-26 03:43:05'),
(22, '2019-11-26', '127.0.0.1', '/public/login/', 'POST', 'No definido', '2019-11-26 03:43:46', '2019-11-26 03:43:46'),
(23, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 03:44:26', '2019-11-26 03:44:26'),
(24, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 03:47:34', '2019-11-26 03:47:34'),
(25, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:48:44', '2019-11-26 03:48:44'),
(26, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:49:52', '2019-11-26 03:49:52'),
(27, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:50:41', '2019-11-26 03:50:41'),
(28, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:51:00', '2019-11-26 03:51:00'),
(29, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:51:42', '2019-11-26 03:51:42'),
(30, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:51:58', '2019-11-26 03:51:58'),
(31, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:52:52', '2019-11-26 03:52:52'),
(32, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 03:53:11', '2019-11-26 03:53:11'),
(33, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 03:53:45', '2019-11-26 03:53:45'),
(34, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:53:50', '2019-11-26 03:53:50'),
(35, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:54:32', '2019-11-26 03:54:32'),
(36, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:56:08', '2019-11-26 03:56:08'),
(37, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:57:45', '2019-11-26 03:57:45'),
(38, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:58:08', '2019-11-26 03:58:08'),
(39, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 03:58:18', '2019-11-26 03:58:18'),
(40, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 03:59:17', '2019-11-26 03:59:17'),
(41, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:00:27', '2019-11-26 04:00:27'),
(42, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'No definido', '2019-11-26 04:00:40', '2019-11-26 04:00:40'),
(43, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:08:49', '2019-11-26 04:08:49'),
(44, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:10:28', '2019-11-26 04:10:28'),
(45, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:11:24', '2019-11-26 04:11:24'),
(46, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:11:42', '2019-11-26 04:11:42'),
(47, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:13:25', '2019-11-26 04:13:25'),
(48, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:14:39', '2019-11-26 04:14:39'),
(49, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:15:12', '2019-11-26 04:15:12'),
(50, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:15:44', '2019-11-26 04:15:44'),
(51, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:16:43', '2019-11-26 04:16:43'),
(52, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'No definido', '2019-11-26 04:16:54', '2019-11-26 04:16:54'),
(53, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email: - Legajo:', '2019-11-26 04:18:46', '2019-11-26 04:18:46'),
(54, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:', '2019-11-26 04:19:13', '2019-11-26 04:19:13'),
(55, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:19:22', '2019-11-26 04:19:22'),
(56, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:20:49', '2019-11-26 04:20:49'),
(57, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:21:28', '2019-11-26 04:21:28'),
(58, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:21:57', '2019-11-26 04:21:57'),
(59, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:22:05', '2019-11-26 04:22:05'),
(60, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:22:27', '2019-11-26 04:22:27'),
(61, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:22:35', '2019-11-26 04:22:35'),
(62, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:23:02', '2019-11-26 04:23:02'),
(63, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:24:09', '2019-11-26 04:24:09'),
(64, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:25:37', '2019-11-26 04:25:37'),
(65, '2019-11-26', '127.0.0.1', '/public/ingreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:26:02', '2019-11-26 04:26:02'),
(66, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:26:05', '2019-11-26 04:26:05'),
(67, '2019-11-26', '127.0.0.1', '/public/egreso/', 'PUT', 'Email:gabriel@gmail.com - Legajo:1', '2019-11-26 04:26:10', '2019-11-26 04:26:10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `clave` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `legajo` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `email`, `clave`, `legajo`, `created_at`, `updated_at`) VALUES
(1, 'gabriel@gmail.com', 'stNEMIKQ2Li.U', 1, '2019-11-26 02:33:06', '2019-11-26 02:33:06'),
(3, 'mario@gmail.com', 'st3X.AckN/VD6', 12, '2019-11-26 03:03:26', '2019-11-26 03:03:26');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ficheos`
--
ALTER TABLE `ficheos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ficheos`
--
ALTER TABLE `ficheos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
